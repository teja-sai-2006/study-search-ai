"""
StudyMate UI Components

Reusable UI components for the StudyMate application.
"""
