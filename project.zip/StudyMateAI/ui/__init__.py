"""
StudyMate UI Package

Contains user interface components and mode implementations.
"""
