"""
StudyMate Utilities Package

This package contains utility modules for document processing, 
LLM integration, search capabilities, and other core functionalities.
"""
